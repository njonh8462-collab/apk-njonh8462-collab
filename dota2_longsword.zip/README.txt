═══════════════════════════════════════════════════════
  Sword Workshop — Dota 2 Export Pack
  Model: longsword
═══════════════════════════════════════════════════════

این بسته شامل فایل‌های زیر است:

  longsword.obj                     — مش مدل (Wavefront OBJ)
  longsword.mtl                     — متریال‌های OBJ
  models/longsword/longsword.vmdl      — تعریف مدل برای Source 2
  materials/longsword/longsword.vmat   — تعریف متریال برای Source 2
  materials/longsword/albedo.png    — بافت رنگ پایه
  materials/longsword/normal.png    — بافت نرمال (برجستگی)
  materials/longsword/roughness.png — بافت زبری

───────────────────────────────────────────────────────
مراحل استفاده در Dota 2 Workshop Tools:
───────────────────────────────────────────────────────

۱. فایل‌های این بسته را در پوشه‌ی محتوای addon خود کپی کنید:
   .../content/dota_addons/<your_addon>/

   ساختار پیشنهادی:
     models/weapons/longsword/longsword.vmdl
     materials/models/weapons/longsword/longsword.vmat
     materials/models/weapons/longsword/albedo.png
     materials/models/weapons/longsword/normal.png
     materials/models/weapons/longsword/roughness.png

۲. فایل OBJ را با استفاده از ابزارهای Valve
   (مثل resourcecompiler یا import خود Hammer) به فرمت
   داخلی موتور تبدیل کنید.

۳. در Hammer یا Model Editor، فایل VMDL را باز کنید و
   مسیر مش را به مدل وارد شده متصل نمایید.

۴. تنظیمات نهایی متریال (رنگ، بازتاب، درخشش) را در
   فایل VMAT مطابق سلیقه‌ی خود تغییر دهید.

───────────────────────────────────────────────────────
نکته: 
این بسته یک نقطه‌ی شروع است. برای ورود نهایی به Dota 2
ممکن است نیاز به تنظیم دستی مقیاس، محور و نام‌گذاری
مش‌ها در ابزارهای رسمی Valve داشته باشید.
═══════════════════════════════════════════════════════
